from .combinacao import transferir_histograma, colar_imagem
from .transformacao import redimensionar_imagem, converter_escala_cinza, rotacionar_imagem